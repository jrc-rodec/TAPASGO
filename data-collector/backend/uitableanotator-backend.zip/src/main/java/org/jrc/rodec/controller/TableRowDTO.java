package org.jrc.rodec.controller;

import java.util.HashMap;
import java.util.Map;

public class TableRowDTO {

    String tableId;
    Map<String, String> rowEntries;
    String question;
    Integer row;
    Integer answerColumn;

    public static TableRowDTO create(String tableId, Map<String, String> rowEntries, Integer row,
                                     String question, Integer answerColumn) {
        TableRowDTO tableRowDTO = new TableRowDTO();
        tableRowDTO.tableId = tableId;
        tableRowDTO.rowEntries = rowEntries;
        tableRowDTO.row = row;
        tableRowDTO.question = question;
        tableRowDTO.answerColumn = answerColumn;

        return tableRowDTO;
    }

    public String getTableId() {
        return tableId;
    }

    public Map<String, String> getRowEntries() {
        return rowEntries;
    }

    public String getQuestion() {
        return question;
    }

    public Integer getRow() {
        return row;
    }

    public Integer getAnswerColumn() {
        return answerColumn;
    }

    public void setRowEntries() {
        rowEntries = new HashMap<>();
    }
}
