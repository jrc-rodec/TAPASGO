package org.jrc.rodec.application;

import com.opencsv.CSVReader;
import io.quarkus.runtime.StartupEvent;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jrc.rodec.application.interfaces.TablesInitService;
import org.jrc.rodec.domain.TableRow;
import org.jrc.rodec.domain.repositories.TableRepository;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.event.Observes;
import javax.inject.Inject;
import java.io.*;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import io.quarkus.logging.Log;
import org.jrc.rodec.microservices.*;


@ApplicationScoped
public class TableInitServiceImpl implements TablesInitService {

    @ConfigProperty(name = "tables.dir")
    String tablesDir;

    @Inject
    TableRepository tableRepository;

    @RestClient
    GenesisApiClient genesisApiClient;

    void onStart(@Observes StartupEvent ev) {
        //initTables();
    }

    @Override
    public void initTables() {
        //extractCSVs();
        Log.info("\n" + new Timestamp(System.currentTimeMillis()) + " INFO Started table init process!");
        List<List<TableRow>> tableList = readTablesFromSource();
        for(List<TableRow> table: tableList)
            tableRepository.insertTable(table);
    }

    private void extractCSVs() {
        List<TableMetaData> tableMetaDataList = genesisApiClient.getTables("DEHSB7NA3A", "Ge54466569$", 10).tableMetaDataList();

        for (TableMetaData tableMetaData: tableMetaDataList
             ) {
            System.out.println(tableMetaData.code() + "loading...");
            GenesisTable genesisTable = genesisApiClient.getTable("DEHSB7NA3A", "Ge54466569$", tableMetaData.code());
            if(genesisTable.tableContent() != null)
                try (PrintWriter out = new PrintWriter(tableMetaData.code() + ".csv")) {
                    System.out.println("Writing " + tableMetaData.code() + ".csv...");
                    out.println(genesisTable.tableContent().content());
                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                }
        }
    }

    private List<List<TableRow>> readTablesFromSource() {
        File tablesDir = new File("tables");
        String[] fileNames = tablesDir.list();

        List<List<TableRow>> CSVTableList = new ArrayList<>();

        for (String fileName : fileNames) {
            try {
                FileReader fileReader = new FileReader(tablesDir + "/" + fileName);
                CSVReader csvReader = new CSVReader(fileReader, ';');
                CSVTableList.add(parseCSVToTable(fileName, csvReader.readAll()));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        return CSVTableList;
    }

    private List<TableRow> parseCSVToTable(String tableName, List<String[]> csv) {
        List<TableRow> table = new ArrayList<>();
        List<String> headerNames = Arrays.stream(csv.get(0)).collect(Collectors.toList());
        csv.remove(csv.get(0));

        int i = 0;
        for (String[] row : csv){
            table.add(TableRow.create(row, headerNames, tableName, i));
            ++i;
        }

        return table;
    }
}
