package org.jrc.rodec.persistence;

import org.jrc.rodec.domain.TableRow;
import org.jrc.rodec.domain.repositories.TableRepository;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@ApplicationScoped
public class TableRepositoryImpl implements TableRepository {

    @Inject
    EntityManager em;

    @Override
    @Transactional
    public Set<TableRow> getAllTableRows() {
        TypedQuery<TableRow> query = em.createQuery(
                        "FROM TableRow", TableRow.class
        );
        return query.getResultStream().collect(Collectors.toSet());
    }

    @Transactional
    public List<TableRow> getTableById(String tableId){
        TypedQuery<TableRow> query = em.createQuery(
                "FROM TableRow " +
                        "WHERE tableId = :tableId", TableRow.class
        );
        query.setParameter("tableId", tableId);
        return query.getResultStream().collect(Collectors.toList());
    }

    @Transactional
    public void insertTable(List<TableRow> table){
        if(getTableById(table.get(0).tableId()).size() == 0)
            table.forEach(tableRow -> em.persist(tableRow));
    }

    @Override
    public Optional<TableRow> getTableRowByTableIdAndRowNumber(String tableId, Integer row) {
        TypedQuery<TableRow> query = em.createQuery(
                "FROM TableRow " +
                        "WHERE TABLE_ID = :tableId AND ROW = :row", TableRow.class
        );
        query.setParameter("tableId", tableId);
        query.setParameter("row", row);
        return query.getResultStream().findAny();
    }

    @Override
    @Transactional
    public Set<TableRow> getUnansweredTableRows() {
        return getAllTableRows()
                .stream()
                .filter(tableRow -> !tableRow.isAnswered())
                .collect(Collectors.toSet());
    }

    @Override
    @Transactional
    public void updateTableRow(TableRow updatedTableRow) {
        em.merge(updatedTableRow);
    }
}
