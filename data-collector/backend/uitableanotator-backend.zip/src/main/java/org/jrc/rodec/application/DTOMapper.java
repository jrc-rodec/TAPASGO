package org.jrc.rodec.application;

import org.jrc.rodec.controller.TableRowDTO;
import org.jrc.rodec.domain.TableRow;

import java.util.Map;
import java.util.stream.Collectors;

public class DTOMapper {
    public static TableRowDTO mapTableRowToRowDTO(TableRow row){
        TableRowDTO rowDTO = TableRowDTO.create(
                row.tableId(), row.rowEntries(), row.row(), row.question(), row.answerColumn()
        );
        rowDTO.setRowEntries();
        row.rowEntries().entrySet().forEach(
                rowEntry -> rowDTO.getRowEntries().put(rowEntry.getKey(), rowEntry.getValue())
        );
        return rowDTO;
    }

    public static TableRow mapTableRowDTOtoTableRow(TableRowDTO tableRowDTO) {
        return TableRow.create(tableRowDTO.getTableId(),
                tableRowDTO.getRowEntries().entrySet().stream().collect(
                        Collectors.toMap(Map.Entry<String, String>::getKey, Map.Entry<String, String>::getValue)
                ), tableRowDTO.getQuestion(), tableRowDTO.getRow(), tableRowDTO.getAnswerColumn(), true);
    }
}
