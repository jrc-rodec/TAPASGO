package org.jrc.rodec.domain;

import net.bytebuddy.build.Plugin;
import org.hibernate.annotations.FetchProfile;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Entity
public class TableRow implements Serializable {
    @Column(name = "TABLE_ID")
    @Id
    String tableId;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "ROW_HEADER_MAPPINGS",
            joinColumns = {@JoinColumn(name = "row"), @JoinColumn(name = "fk_table_id")})
    @MapKeyColumn(name = "header")
    @Column(name = "row_entry")
    Map<String, String> rowEntries;
    String question;
    @Id
    Integer row;
    Integer answerColumn;
    Boolean isAnswered = false;

    public static TableRow create(String tableId,  Map<String, String> rowEntries, String question,
                                  Integer row, Integer answerColumn, boolean isAnswered){
        TableRow tableRow = new TableRow();
        tableRow.row = row;
        tableRow.rowEntries = rowEntries;
        tableRow.answerColumn = answerColumn;
        tableRow.isAnswered = isAnswered;
        tableRow.question = question;
        tableRow.tableId = tableId;

        return tableRow;
    }

    public static TableRow create(String[] rowContents, List<String> headerNames, String tableId, int rowIndex) {
        TableRow row = new TableRow();
        row.row = rowIndex;
        row.rowEntries = new HashMap<>();
        for (int i = 0; i < rowContents.length; i++) {
            row.rowEntries.put(headerNames.get(i), rowContents[i]);
        }
        row.tableId = tableId;

        return row;
    }


    public Map<String, String> rowEntries() {
        return rowEntries;
    }

    public String tableId(){
        return tableId;
    }

    public String question() {
        return question;
    }

    public Integer row() {
        return row;
    }

    public Integer answerColumn() {
        return answerColumn;
    }

    public Boolean isAnswered() {
        return isAnswered;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TableRow tableRow = (TableRow) o;

        if (!tableId.equals(tableRow.tableId)) return false;
        return row.equals(tableRow.row);
    }

    @Override
    public int hashCode() {
        int result = tableId.hashCode();
        result = 31 * result + row.hashCode();
        return result;
    }

    public void assignColumnAndQuestion(Integer answerColumn, String question) {
        isAnswered = true;
        this.answerColumn = answerColumn;
        this.question = question;
    }
}
