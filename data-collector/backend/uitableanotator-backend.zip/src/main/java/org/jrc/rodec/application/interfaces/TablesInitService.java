package org.jrc.rodec.application.interfaces;

public interface TablesInitService {
    public void initTables();
}
